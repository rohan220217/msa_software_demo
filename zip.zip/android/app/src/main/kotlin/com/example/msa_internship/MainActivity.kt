package com.example.msa_internship

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
